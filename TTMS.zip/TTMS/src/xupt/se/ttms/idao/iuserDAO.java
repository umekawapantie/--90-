package xupt.se.ttms.idao;

import java.util.List;

import xupt.se.ttms.model.user;

public interface iuserDAO
{
	public int insert(user user);
	public List<user> select(String username);
	public String selectuserpassword(String username);
    public int delete(String username);
    public int modify(user user);
}
