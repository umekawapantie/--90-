package xupt.se.ttms.idao;

import java.util.List;

import xupt.se.ttms.model.Schedule;

public interface iScheduleDAO
{
    public int insert(Schedule stu);

    public int update(Schedule stu);

    public int delete(int ScheduleID);//根据演出计划ID删除

    public List<Schedule> select(int PlayID);//根据剧目ID搜索
}
