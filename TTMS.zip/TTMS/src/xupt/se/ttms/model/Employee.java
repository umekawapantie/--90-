package xupt.se.ttms.model;
import java.util.Date;//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

public class Employee {
	private int EmpId=0; 
	private String EmpName="";
	private String EmpGender="";
	private String EmpTelnum="";
	private String EmpEmail="";
	private String EmpPwd="";
	private String EmpPower="";
	//private String EmpPower="";
	public Employee(){
		EmpId = 0;
	}
	public Employee(int EmpId, String EmpName, String EmpGender, String EmpTelnum,String EmpEmail, String EmpPwd,String EmpPower){
		this.EmpId=EmpId; 
		this.EmpName=EmpName;
		this.EmpGender=EmpGender;
		this.EmpTelnum=EmpTelnum;
		this.EmpEmail=EmpEmail;
		this.EmpPwd=EmpPwd;	
		this.EmpPower=EmpPower;
	}

	public int getEmpId() {
		return EmpId;
	}
	public void setEmpId(int EmpId) {
		this.EmpId = EmpId;
	}
	public void setEmpName(String EmpName){
		this.EmpName=EmpName;
	}
	
	public String getEmpName(){
		return EmpName;
	}
	
	public void setEmpGender(String EmpGender){
		this.EmpGender=EmpGender;
	}
	
	public String getEmpGender(){
		return EmpGender;
	}
	public void setEmpTelnum(String EmpTelnum){
		this.EmpTelnum=EmpTelnum;
	}
	
	public String getEmpTelnum(){
		return EmpTelnum;
	}
	
	public void setEmpEmail(String EmpEmail){
		this.EmpEmail=EmpEmail;
	}
	
	public String getEmpEmail(){
		return EmpEmail;
	}	
	public void setEmpPwd(String EmpPwd) {
		this.EmpPwd=EmpPwd;
	}
	public String getEmpPwd() {
		return EmpPwd;
	}
	public void setEmpPower(String EmpPower){
		this.EmpPower=EmpPower;
	}
	
	public String getEmpPower(){
		return EmpPower;
	}
}
